package com_interface;

public class B implements A {
	public void text(){
		System.out.println("from text");
		
	}
	public static void main(String[] args) {
		B b1=new B();
		b1.text();
	}
	
	

}
