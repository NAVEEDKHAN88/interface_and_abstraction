package com_interface;

public class C {
	 static int n=10;

	public static void main(String[] args) {
		C c1=new C(); 
		System.out.println("value of n is:"+n);
	 

	}

}
