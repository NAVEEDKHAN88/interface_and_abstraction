package com_interface;

public interface A {
	public void text();

}
 


