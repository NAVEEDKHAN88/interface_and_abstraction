package com_interface1;

public class hidden implements show{
	public void one(){
		System.out.println("the no is one");
	}

	@Override
	public void two() {
		System.out.println("the no is two");
		
	}

	@Override
	public void three() {
		System.out.println("the no is three");
		
	} 
	public static void main(String[] args) {
		hidden h1=new hidden();
		h1.one();
		h1.two();
		h1.three();
	}

}
