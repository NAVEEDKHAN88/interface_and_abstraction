package com_interface1;

public interface show {
	public void one();
	public void two();
    public void three();
}
