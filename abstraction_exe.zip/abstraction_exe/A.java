package com.abstraction_exe;

public abstract interface A {
	public abstract void text1();

}
