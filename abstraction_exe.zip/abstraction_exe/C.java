package com.abstraction_exe;

public class C extends B{

	public void text1() {
		System.out.println("from text 1");
		
	}

	
	public void text2 () {
   System.out.println("from text 2");
		 
	}
	public static void main(String[] args) {
		C c1 =new C();
		c1.text1();
		c1.text2();
	}

}
