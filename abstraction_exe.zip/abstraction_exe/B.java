package com.abstraction_exe;

public abstract class B implements A{
	public abstract void text2();
}
