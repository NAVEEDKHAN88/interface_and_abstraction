package com.multipleinterface;

public interface C extends A,B {
	public void car();

}
