package com.multipleinterface;

public interface B {
	public void bus();

}
