package com.multipleinterface;

public class D implements C{
 public void vehicle() {
	 System.out.println("vehicle");
	 
 }

@Override
public void bus() {
	 System.out.println("vehicle type is bus");
		
	}
	


@Override
public void car() {
	 
		System.out.println("vehicle type is car");
	}
	

 public static void main(String[] args) {
	 D d1=new D();
	 d1.vehicle();
	 d1.bus();
	 d1.car();
 } 
}
