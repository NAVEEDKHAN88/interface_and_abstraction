package com.multipleinterface;

public interface A {
	public void vehicle ();

}
